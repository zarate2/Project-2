"""Simple configurable portfolio screen, preserving the Lab 15 estimator."""
from copy import deepcopy
from math import fsum, isfinite
import json
from pathlib import Path

import portfolio as p
from signal_data import cpi_signal, verify_prices

ROOT = Path(__file__).resolve().parent
ANNOUNCEMENT = ('AI disclosure: OpenAI Codex helped implement, test and draft this baseline. '
                'Student review and the required personal ownership statement are pending.\n\n'
                'For education, not investment advice.')
DECISION = ('PILOT in paper research only, with 0% new capital authorized. Reverse toward adoption '
            'only after the committee approves the mandate and signal, net rolling-five-year/payout '
            'validation passes, and liquidity, turnover and implementation costs are evidenced.')
DEPLOYMENT_GAPS = ['committee approval of proposed assumptions', 'net rolling-five-year and payout validation',
                   'observed liquidity and annual turnover', 'implementation and out-of-sample validation']


def load_config():
    return json.loads((ROOT / 'config.json').read_text())


def validate_config(c):
    if c['tickers'] != ['BIL', 'IEF', 'LQD', 'VT']:
        raise ValueError('Baseline universe must be BIL, IEF, LQD, VT. Change the model explicitly to extend it.')
    for key in ('fixed_inflation', 'real_return_target', 'additional_annual_cost', 'reserve_floor',
                'volatility_limit', 'equity_weight_limit', 'minimum_five_day_liquidity',
                'nonexempt_issuer_limit', 'annual_turnover_limit'):
        value = c[key]
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not isfinite(value) or not 0 <= value <= 1:
            raise ValueError(f'{key} must be a decimal rate between 0 and 1.')
    if not isfinite(c['vt_return_shift']):
        raise ValueError('VT shift must be finite.')
    if (not isfinite(c['portfolio_value_usd']) or not isfinite(c['quarterly_payout_usd'])
            or c['portfolio_value_usd'] <= 0 or c['quarterly_payout_usd'] < 0):
        raise ValueError('Portfolio must be positive; payout cannot be negative.')
    if c['inflation_mode'] not in ('vintage_cpi_proxy', 'fixed_assumption'):
        raise ValueError('Unknown inflation mode.')
    p.validate_weights(c['benchmark_weights'], 4)


def grid():
    for a in range(21):
        for b in range(21 - a):
            for c in range(21 - a - b):
                yield [a/20, b/20, c/20, (20-a-b-c)/20]


def evaluate(weights, sleeves, covariance, config, target, floor):
    row = p.evaluate(weights, sleeves, covariance, target + config['additional_annual_cost'])
    row['gross_return'] = row.pop('return')
    row['net_return'] = row['gross_return'] - config['additional_annual_cost']
    rules = {
        'Fully invested and long-only': abs(fsum(weights)-1) <= 1e-12 and min(weights) >= 0,
        'Net return proxy >= inflation proxy + real target': row['net_return'] + 1e-12 >= target,
        'Reserve weight >= floor': row['reserve'] + 1e-12 >= floor,
        'Annual volatility <= proposed limit': row['volatility'] <= config['volatility_limit'] + 1e-12,
        'VT weight <= proposed cap': weights[3] <= config['equity_weight_limit'] + 1e-12,
    }
    row['rules'] = {name: 'PASS' if ok else 'FAIL' for name, ok in rules.items()}
    row['failed_rules'] = [name for name, ok in rules.items() if not ok]
    row['modeled_verdict'] = 'FAIL' if row['failed_rules'] else 'PASS'
    row['deployment_verdict'] = 'FAIL — unresolved validation/approval gates'
    return row


def calculate(config=None):
    c = deepcopy(load_config() if config is None else config)
    validate_config(c)
    source = verify_prices(c['decision_date'])
    signal = cpi_signal(c['decision_date'])
    inflation = signal['year_over_year'] if c['inflation_mode'] == 'vintage_cpi_proxy' else c['fixed_inflation']
    target = inflation + c['real_return_target']
    payout_floor = 4 * c['quarterly_payout_usd'] / c['portfolio_value_usd']
    floor = max(c['reserve_floor'], payout_floor)
    if floor > 1:
        raise ValueError('Twelve-month payout reserve exceeds portfolio value; stop.')
    estimate = p.estimate_from_csv(ROOT / 'prices.csv', last_36=c['last_36'])
    if [s['name'] for s in estimate['sleeves']] != c['tickers']:
        raise ValueError('Price universe/order does not match the mandate.')
    estimate['sleeves'][3]['return'] += c['vt_return_shift']
    sleeves = estimate['sleeves']
    cov = p.covariance_matrix(sleeves, estimate['correlations'])
    baselines = {'Equal weight': p.equal_weights(sleeves),
                 'Inverse volatility': p.inverse_volatility_weights(sleeves),
                 '60/40 benchmark': c['benchmark_weights']}
    rows = {name: evaluate(w, sleeves, cov, c, target, floor) for name, w in baselines.items()}
    best = None
    for weights in grid():
        row = evaluate(weights, sleeves, cov, c, target, floor)
        if not row['failed_rules'] and (best is None or row['volatility'] < best['volatility'] - 1e-12):
            best = row
    rows['Constrained portfolio'] = best
    return {'config': c, 'price_source': source, 'signal': signal, 'inflation_used': inflation,
            'net_return_target': target, 'effective_reserve_floor': floor, 'estimate': estimate,
            'portfolios': rows, 'status': 'FEASIBLE' if best else 'STOP — no feasible 5-point mix',
            'decision': DECISION if best else 'REJECT this scenario: no feasible mix; do not relax limits automatically.',
            'deployment_gaps': DEPLOYMENT_GAPS}


def stress_suite(config=None):
    base = load_config() if config is None else config
    changes = {
        'Base': {},
        'Estimate: VT minus 1 percentage point': {'vt_return_shift': base['vt_return_shift'] - .01},
        'Window: 36 months' if not base['last_36'] else 'Window: 60 months': {'last_36': not base['last_36']},
        'Cost: plus 1 percentage point annually': {'additional_annual_cost': base['additional_annual_cost'] + .01},
        'Constraint: VT cap tightened to at most 25%': {'equity_weight_limit': min(base['equity_weight_limit'], .25)},
    }
    return {name: calculate(dict(base, **change)) for name, change in changes.items()}


def table_rows(result):
    records = []
    for name, row in result['portfolios'].items():
        if row is None:
            records.append({'Portfolio': name, 'Weights BIL / IEF / LQD / VT': 'No feasible mix',
                            'Gross': '—', 'Net proxy': '—', 'Volatility': '—', 'Reserve': '—',
                            'Modeled verdict': 'FAIL: infeasible', 'Deployment': 'FAIL'})
        else:
            records.append({'Portfolio': name, 'Weights BIL / IEF / LQD / VT': ' / '.join(f'{w:.2%}' for w in row['weights']),
                            'Gross': f"{row['gross_return']:.2%}", 'Net proxy': f"{row['net_return']:.2%}",
                            'Volatility': f"{row['volatility']:.2%}", 'Reserve': f"{row['reserve']:.2%}",
                            'Modeled verdict': row['modeled_verdict'] + (': ' + '; '.join(row['failed_rules']) if row['failed_rules'] else ''),
                            'Deployment': row['deployment_verdict']})
    return records


def markdown_table(rows):
    headings = list(rows[0])
    lines = ['| ' + ' | '.join(headings) + ' |', '| ' + ' | '.join(['---'] * len(headings)) + ' |']
    return '\n'.join(lines + ['| ' + ' | '.join(str(row[key]) for key in headings) + ' |' for row in rows])
