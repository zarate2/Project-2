# Change log

## 2026-11-22 — student mandate choices and rationale

- Recorded the student's Treasury-relative target, six-to-seven-year preference (seven-year implementation proposal), domestic-equity/Treasury/corporate-bond universe, 60/40 comparison, 10% volatility ceiling and minimum-risk selection preference.
- Confirmed the assignment does not require withdrawals; the revised mandate removes them and their derived reserve requirement. This still needs implementation in the app.
- Distinguished the proposed 4-point return premium and 5-point stress from an approved student choice. Corrected the premise that equity horizons should not exceed seven years and avoided promising returns for taking risk.
- Added a sourced rationale and migration checklist. Marked the old app results as applying only to the old mandate. No model inputs, source data, calculation logic or experiment results changed in this policy-drafting step.

## 2026-11-22 — audit against the supplied Brightspace rubric

- Preserved the six-page rubric and recorded its hash; visually reviewed every page and mapped existing evidence and gaps to its six criteria and 300-point weighting.
- Independently matched all 244 price values to the retained raw responses, verified CPI snapshot hashes and confirmed saved outputs match the latest recorded isolated run.
- Identified the annual-screen versus five-year/payout evidence gap and the single available five-year window as priorities; distinguished financial limitations from missing submission artifacts.
- Documented the Edition A/B wording conflict while retaining the explicit Project 2 submission exception. Clarified analyst/committee users without inventing a client.
- Corrected the README's reproduction date and documented the pinned dependency's Python 3.9.7 exclusion. No numerical settings, model logic or human experiment changed.

## 2026-11-22 — unnamed portfolio and app walkthrough

- Removed the invented client identity from the active app, configuration and documents; retained the numerical mandate as explicit sample assumptions and original lab sources as historical evidence.
- Replaced client approval wording with committee review and regenerated existing outputs without changing the financial methodology or numerical settings.
- Recorded the student-reported November 23, 11:59 p.m. deadline and repository status. Explained that the required GitHub prediction must precede its changed-case run.
- Expanded the student guide with a plain-language assignment summary, exact app exploration steps and the purpose of actual partner review.
- Added an immediate-recalculation notice to the sidebar. Reproduced the existing scenarios and ran the project checks; these are development checks, not a human AI-off experiment.

## 2026-11-22 — Project 1 feedback applied to documents

- Kept the Project 2 portfolio objectives and checked the current course assignment/checklist. Corporate valuation requirements need instructor clarification; Edition A/B and Research-Evolution uploads are excluded for Project 2.
- Simplified the committee memo, clarified scenario ranges and the optimizer's increased equity exposure under adverse assumptions, and preserved all reported financial results.
- Added explicit fact/assumption provenance, prediction-before-run steps, a real partner challenge form, and face-visible video/transcript checks.
- Expanded the manifest with artifact, freeze, access and Brightspace receipt checks. The original baseline archive and hashes remain historical references.
- Recorded this AI-assisted revision. Student ownership, AI-off prediction, partner evidence, recordings and publication remain pending; none were invented or attested for the student.
- Model code, configuration, retained source data and financial output files are unchanged. Verification for this revision is limited to document links, saved-result consistency and preservation checks; no new financial experiment was executed.
- Follow-up: student confirmed the Project 2 assignment controls scope. Clarified that the student had not selected an example from earlier Lab 13 work. Added student review steps and a labeled AI practice critique for a possible Gage Hodson discussion; no real interaction or personal review is claimed.

## 0.1.0 — 2026-11-19 — working baseline

- Created a separate Project 2 application from Labs 13–19 with a central editable configuration.
- Preserved the Lab 15 estimator and original 75% BIL / 25% VT reference.
- Added an exact prior-day CPI vintage gate and proposed trailing-inflation expectation proxy.
- Added a 0.25% additional-cost assumption, proposed 10% volatility limit and 60% VT cap.
- Displayed two transparent baselines plus benchmark and constrained allocation, with named rule failures and a separate deployment gate.
- Added estimate, window, cost and constraint stresses, including a no-feasible-allocation stop.
- Included saved, audited NVDA investor research as a later-dated supplementary exhibit, excluded from allocation decisions.
- Prepared visible results, decision memo, data card, validation, requirement manifest and personal activity templates.
- Kept client approval, full performance/implementation validation, personal records, videos and publication open.

Future versions should record the changed input or code, reason, before/after decision, verification and updated evidence. Keep the baseline ZIP for comparison. This log is not a human AI-off prediction record.
