AI disclosure: OpenAI Codex helped implement, test and draft this baseline. Student review and the required personal ownership statement are pending.

For education, not investment advice.

# Project 2 — baseline 0.1.0

PILOT in paper research only, with 0% new capital authorized. Reverse toward adoption only after the committee approves the mandate and signal, net rolling-five-year/payout validation passes, and liquidity, turnover and implementation costs are evidenced.

Review date: 2026-11-22. Portfolio decision date: 2026-10-30. Prices downloaded 2026-10-20, through 2026-09. No market data is refreshed by this command.

## Material inputs

Sample portfolio (no named client): $10,000,000; quarterly payouts $50,000; horizon 7 years. Effective reserve floor 2.00%. Additional annual cost 0.25%; proposed volatility limit 10.00%; proposed VT cap 60%. These proposed controls require committee review.

CPI vintage 2026-10-29: latest measured month 2026-09, index 336.298 versus 324.245 one year earlier. Trailing inflation = 3.717251%. Inflation mode: `vintage_cpi_proxy`; inflation used 3.717251% plus real target 3.00% gives net return screen 6.717251%. Trailing inflation is a proposed expectation proxy; this arithmetic annual screen does not establish net rolling-five-year performance.

## Baselines and constrained portfolio

| Portfolio | Weights BIL / IEF / LQD / VT | Gross | Net proxy | Volatility | Reserve | Modeled verdict | Deployment |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Equal weight | 25.00% / 25.00% / 25.00% / 25.00% | 3.22% | 2.97% | 7.50% | 50.00% | FAIL: Net return proxy >= inflation proxy + real target | FAIL — unresolved validation/approval gates |
| Inverse volatility | 86.81% / 5.75% / 4.49% / 2.95% | 3.33% | 3.08% | 1.40% | 92.56% | FAIL: Net return proxy >= inflation proxy + real target | FAIL — unresolved validation/approval gates |
| 60/40 benchmark | 0.00% / 0.00% / 40.00% / 60.00% | 6.81% | 6.56% | 12.29% | 0.00% | FAIL: Net return proxy >= inflation proxy + real target; Reserve weight >= floor; Annual volatility <= proposed limit | FAIL — unresolved validation/approval gates |
| Constrained portfolio | 55.00% / 0.00% / 0.00% / 45.00% | 7.33% | 7.08% | 6.78% | 55.00% | PASS | FAIL — unresolved validation/approval gates |

## Four stress dimensions

| Scenario | BIL / IEF / LQD / VT | Net proxy | Volatility | Status |
| --- | --- | --- | --- | --- |
| Base | 55% / 0% / 0% / 45% | 7.08% | 6.78% | FEASIBLE |
| Estimate: VT minus 1 percentage point | 50% / 0% / 0% / 50% | 6.99% | 7.52% | FEASIBLE |
| Window: 36 months | 80% / 0% / 0% / 20% | 7.29% | 2.37% | FEASIBLE |
| Cost: plus 1 percentage point annually | 45% / 0% / 0% / 55% | 6.91% | 8.26% | FEASIBLE |
| Constraint: VT cap tightened to at most 25% | No feasible mix | — | — | STOP — no feasible 5-point mix |

Research allocation range over feasible cases: **BIL: 45%–80%; IEF: 0%–0%; LQD: 0%–0%; VT: 20%–55%**. Live allocation authorization: **0% new capital**. An infeasible case has no portfolio and is excluded from that range; it is never replaced with relaxed constraints.

## Connection to the earlier labs

With the fixed 2.5% inflation assumption and zero additional costs, the retained Lab 15 reference is 75% / 0% / 0% / 25% in BIL / IEF / LQD / VT, 5.67% gross return and 3.83% volatility.

This baseline uses the dated CPI proxy and additional-cost screen explicitly, so its starting weights can differ from Lab 15. Investor research is supplementary: Warren Buffett: Watch it; Cathie Wood: Own the business; Michael Burry: Pass. These educational persona judgments are not the actual investors' opinions and do not change ETF weights.

## Decision conditions and remaining work

The modeled checks cover fully funded long-only weights, a net return proxy, reserve coverage, modeled annual volatility and the VT cap. Every deployment verdict fails pending approval and evidence. The mandate also requires 90% five-day liquidity, an 8% nonexempt issuer cap, and 25% annual turnover without approval. Fund exemptions are an exercise convention; execution and eligibility need verification.

Stop when the grid is infeasible, required vintage is missing, source hashes do not match, or inputs are invalid. Monitor reserves/liquidity before payouts, turnover before trades, vintage eligibility at each rebalance, realized risk against approved limits, and net real rolling returns when sufficient history exists. A mandate to deploy before the approval/validation gates pass changes the decision to reject.

AI-off prediction and prior GitHub commit, partner cold run, student ownership statement, video recordings/transcripts and final publication remain pending. This baseline is a starting version for iteration, not a completed submission.

Full precision and all inputs are in `outputs/results.json`. Run `python3 run.py` from this project folder to reproduce.
