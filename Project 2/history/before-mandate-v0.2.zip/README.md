AI disclosure: OpenAI Codex helped implement, test and draft this baseline. Student review and the required personal ownership statement are pending.

For education, not investment advice.

# Project 2 — Investment Management Application

**Model version 0.1.0; documents revised November 22, 2026.** Built from Labs 13–19. This folder is self-contained; future changes go here. The original labs remain the historical reference. The companion `Project 2 - Baseline v0.1.0.zip` and `BASELINE.json` preserve the initial version; their hashes describe that version, not these revised documents.

Project 2 evaluates a portfolio process: a mandate, two baselines, a constrained portfolio, a dated signal, stress results and a committee decision. The [feedback response](docs/feedback-response.md) explains how the Project 1 lessons apply and identifies the assignment differences.

**Mandate revision in progress:** the [student's new policy direction](docs/mandate-revision.md) uses a Treasury-relative target, domestic equities and no scheduled withdrawals. The app and numbers below still describe the previous baseline; new policy results must be calculated before these are replaced.

**Starting decision: PILOT in paper research only, with 0% new capital authorized.** Reverse toward adoption only after committee approval of the mandate and signal, net rolling-five-year/payout validation, and evidence for liquidity, turnover and implementation costs. The model's current research allocation is **55% BIL / 45% VT**, with **7.08% estimated net annual return** and **6.78% annual volatility**. These are historical-model estimates, not realized future outcomes or a live trading recommendation.

## Start the app

Requires Python 3.9+ excluding 3.9.7, which the pinned Streamlit version does not support; open a terminal in this folder. Install once:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Then start the interactive app:

```sh
.venv/bin/python -m streamlit run app.py
```

Open the URL Streamlit prints. On Windows use `.venv\Scripts\python.exe` in place of `.venv/bin/python`. This application reads saved evidence and requires no token, contact details or network access after dependency installation. From the existing course workspace, the installed environment can also launch it:

```sh
"Lab 15/.venv/bin/python" -m streamlit run "Project 2/app.py" --server.port 8522
```

The sidebar changes the inflation method, history window, expected return, additional cost, reserve floor and proposed risk limits. Tabs show portfolio verdicts, the point-in-time CPI calculation, four stress dimensions and the retained investor panel. Download buttons preserve the actual settings and results without changing the default configuration.

## One command reproduces the visible decision

From this folder, no third-party packages or network are needed:

```sh
python3 run.py
```

It prints the report and updates [visible-output.md](outputs/visible-output.md) and [results.json](outputs/results.json). Preserve downloaded before/after outputs for an experiment: rerunning overwrites these two standard output files. From another directory, `python3 "/absolute/path/to/Project 2/run.py"` also works.

## Baseline assumptions we can change

Defaults live in [config.json](config.json). There is no named client: the Project 2 assignment does not prescribe one. The existing $10 million portfolio, seven-year horizon, $50,000 quarterly payouts and CPI + 3% net objective are sample mandate assumptions retained from the earlier Lab 13 work, not instructor-specified numbers. A defined mandate is still required to evaluate the process. Universe: BIL, IEF, LQD and VT. Baselines: equal weight and inverse volatility, plus a 60% VT / 40% LQD evaluation benchmark inherited from the lab exercise.

New **proposed** settings make this baseline testable: 0.25% additional annual costs, 10% modeled volatility limit, 60% VT cap, and trailing inflation from a dated CPI vintage as the expected-inflation proxy. These are editable design assumptions, not committee-approved instructions. CPI 3.717251% plus a 3% real target gives a 6.717251% net annual screen. The additional cost is beyond expenses already embedded in adjusted prices.

The portfolio decision date is **October 30, 2026**; prices were downloaded October 20 and end in September. CPI comes only from the **October 29 vintage**. This is a frozen historical example first reviewed November 19 and reproduced November 22, not today's market view. The November 19 SEC investor panel is supplementary research and is excluded from the October 30 allocation logic.

To reproduce Lab 15's simpler result in the app, select **Fixed inflation assumption**, retain 2.5%, and set **Additional annual cost** to zero with other defaults unchanged: **75% BIL / 25% VT**, 5.67% gross return and 3.83% volatility. That reference is also in the saved report.

## Evidence and iteration

- [Decision memo](docs/decision-memo.md)
- [Mandate and proposed settings](docs/mandate.md)
- [Data card and information timing](docs/data-card.md)
- [Validation and AI use](docs/validation-and-ai-use.md)
- [How Labs 13–19 are used](docs/lab-map.md)
- [Next changes](docs/roadmap.md) and [change log](CHANGELOG.md)
- [Requirement/submission manifest](docs/submission-manifest.md)
- [Locked Changed-Input Record — pending](docs/locked-changed-input.md)
- [Partner cold-run record — pending](docs/cold-run.md)
- [Partner challenge record — pending](docs/partner-challenge.md)
- [Video and transcript checklist](docs/video-checklist.md)
- [Student review and next steps](docs/student-review.md)
- [Rubric review and revision priorities](docs/rubric-review.md)

After installing the app dependency, run the checks:

```sh
.venv/bin/python support/check_results.py
```

Results are saved in [Verification.txt](outputs/Verification.txt). Tests cover independent numerical calculations, source integrity, no-leak timing gates, costs and limits, investor memo bindings, app controls, and an isolated README run. They do not substitute for an actual partner run or a human AI-off prediction.

For ordinary development: change the configuration or model, run `python3 run.py`, run the checks, then update the memo and change log to match. For the required human experiment, first follow the [prediction-before-run procedure](docs/locked-changed-input.md); do not execute the changed case until the student's AI-off prediction is committed and pushed. Preserve the original baseline ZIP. Never reuse an earlier prediction commit as evidence for a new experiment.

This is not yet a final submission. GitHub URLs, the independent prediction/commit, student ownership statement, partner activities, video/transcript links and several deployment validations remain open in the manifest. The course's exact ownership wording should be added truthfully after personal review; the AI has not attested on the student's behalf.
