# Proposed baseline mandate

**Revision pending:** the student's November 22 choices are explained in the [revised mandate draft](mandate-revision.md): a Treasury-relative return goal, seven years, no scheduled withdrawals and domestic equities with Treasury/corporate bonds. The table below describes the still-running baseline until those changes are implemented and validated. Its results do not establish performance under the new mandate.

No named client is used. The Project 2 assignment requires a mandate from Lab 13 but does not specify a client. The amounts, horizon, payouts and limits below are sample assumptions from the earlier work; they are not instructor-specified or approved real-client instructions. The app helps a committee decide whether to adopt a portfolio process under these rules.

**Intended users and action:** a portfolio analyst compares allocations and reports rule failures; an investment committee decides whether to permit paper testing or adopt the process. The current request is paper testing only, with no new capital. The student must review the rationale for the sample mandate before presenting it as their chosen policy.

| Item | Baseline | Origin/status |
|---|---|---|
| Capital, horizon, distributions | $10m; seven years; $50,000 quarterly | Lab 13 proposal |
| Objective | CPI + 3% annually net of costs over rolling five years | Lab 13 proposal; not established by a one-year arithmetic screen |
| Universe | BIL, IEF, LQD, VT | Labs 14–15 |
| Evaluation benchmark | 60% VT / 40% LQD | Inherited exercise proxy; approve with committee |
| Position constraints | Long-only, fully funded, no borrowing/short sales/derivatives | Lab 13; enforced for these weights |
| Reserve | At least twelve months of payouts; initial 2% | Derived as $200,000/$10m; actual floor is max of payout floor and configured floor |
| Reserve eligibility | BIL and IEF | Provisional Treasury fund proxies; confirm eligibility; IEF retains duration risk |
| Five-day liquidity | At least 90% | Lab 13; execution evidence pending |
| Issuer concentration | At most 8% per nonexempt company; diversified funds exempt under exercise convention | Lab 13; confirm implementation/exemptions |
| Annual turnover | At most 25% without approval | Lab 13; no trade ledger or initial holdings supplied |
| Turnover convention | Lesser of purchases/sales divided by average month-end NAV; cash movements excluded, trades for payouts included | Lab 13 proposed definition; not a one-period weight-distance shortcut |
| Review/rebalance | Annual, while funding payouts and maintaining reserves | Lab 13; operational simulation pending |
| Risk measure | Annualized sample volatility, maximum 10% | New proposed research limit; not a loss guarantee |
| Equity limit | VT at most 60% | New proposed research constraint |
| Optimization | Lowest modeled volatility on a 5-percentage-point grid, meeting the net return proxy and other modeled limits | Lab 15 method extended; committee objective approval pending |
| Inflation expectation | Latest same-vintage CPI year-over-year rate; fixed 2.5% remains a selectable alternative | New proposed signal use based on Labs 16–17; trailing inflation is not a forecast |
| Additional cost | 0.25% annually beyond expenses embedded in adjusted prices | Proposed assumption; needs implementation estimate |

The app reports both **modeled PASS/FAIL with named rules** and **deployment FAIL** until approval and validation gaps close. No asset weights alone can establish future payout funding, net rolling returns, annual turnover or executable liquidity. Configured risk and equity limits make the baseline falsifiable without pretending to resolve the committee's risk policy.

Committee ask: permit paper research with zero new capital; confirm the mandate, benchmark, CPI interpretation, reserve eligibility and risk policy before considering deployment. The [original mandate excerpt](../sources/lab-reference/Lab13-mandate.md) is preserved for comparison.
