# Cold-run record

## Automated local isolation check

The checker copies this project without neighboring labs, runs `python3 run.py` inside that copy, and compares generated output with the working baseline. It records the command, time, exit code, elapsed seconds, result path and hashes in [cold-run.json](../outputs/cold-run.json), with [stdout](../outputs/cold-run.txt). It uses the existing system Python and performs no new dependency installation. This is not a partner run or a GitHub access check.

The interactive app is separately exercised by Streamlit AppTest using the installed dependency environment. That validates control behavior but does not claim a stranger installed the app or used its UI successfully.

## Independent partner run — pending

Send only the published repository/folder link. The partner uses their own folder and follows only the README. Record their actual experience without coaching:

- Partner, date, repository URL and commit: PENDING.
- Timezone and confirmation the partner followed only the README: PENDING.
- OS/Python and exact command: PENDING.
- First failure, or explicit no-failure observation: PENDING.
- Elapsed time and result location: PENDING.
- App control changed and before/after rule verdict: PENDING.
- Repair commit/push and independent rerun result, or clean-run note: PENDING.

Do not substitute the automated note for the required independent activity.

Record the partner's substantive question and your response in the [partner challenge record](partner-challenge.md). A successful install establishes usability; a challenge documents scrutiny of the reasoning.
