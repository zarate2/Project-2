# Validation and AI use

Model baseline 0.1.0, prepared November 19, 2026; documents revised November 22. The recommendation is paper research with zero new capital. The evidence below supports the saved calculations; it does not establish readiness for deployment.

The student's subsequent [mandate revision](mandate-revision.md) is pending implementation. Existing calculations and tests apply to the old inflation/global-equity/payout setup, not the proposed Treasury-relative/domestic-equity/no-withdrawal setup. The new rationale was drafted with OpenAI Codex assistance from the student's input and checked against linked primary sources; it is not AI-off prediction evidence.

## Sources and calculation

[Data card](data-card.md) documents units, dates, source hashes and permitted uses. [Import manifest](../sources/import-manifest.json) tracks copied lab artifacts. The original Lab 15 estimator and Lab 19 SEC/panel modules are unchanged; `model.py` adds costs/constraints and `signal_data.py` implements the CPI admission rule. [Full output](../outputs/results.json) retains every scenario configuration and estimate.

Portfolio means use monthly arithmetic returns × 12; risk uses sample covariance × 12. The search examines all 1,771 fully funded, long-only four-asset mixes in five-point increments and chooses the feasible mix with the lowest volatility. Equal-risk ties retain the first grid mix. An empty feasible set returns no portfolio; no automatic target or constraint relaxation occurs.

Net return is an annual arithmetic gross estimate less a flat additional annual cost. It is an approximation for screening, not a wealth simulation. Fees already reflected in adjusted prices are not separately charged again; the 0.25% baseline is a proposed additional cost. No net rolling-five-year compounded return, payout path, trade ledger or realized maximum-loss guarantee is established.

## Baselines and mandate checks

Equal weight, inverse volatility and the 60/40 reference share the same inputs as the constrained portfolio. Each row reports modeled pass/fail and names failed rules: net return proxy, reserve floor, annual volatility ceiling and equity cap. Fully invested/long-only weights are also checked. Every deployment verdict fails until committee approval and validation gaps close. Liquidity, turnover, payout funding, issuer exemptions and operational reserve eligibility remain unverified.

The baseline's 10% volatility limit, 60% VT cap, additional cost and CPI expectation proxy are new proposed assumptions. The original Lab 13 objective is preserved. The app does not imply that these choices were approved by the student or a client.

## Stress results and stop condition

The [visible report](../outputs/visible-output.md) retains separate changes to VT's expected return, the estimation window, annual costs and the VT constraint. The baseline is 55% BIL / 45% VT; the feasible cases range from 45–80% BIL and 20–55% VT. Tightening VT's cap to 25% makes the grid infeasible. The process rejects that scenario instead of using the previous allocation. Missing vintages, corrupted inputs and invalid configurations also stop the calculation.

These scenarios were AI-assisted and their outcomes are already known. They are not the required human AI-off prediction. The [Locked Changed-Input Record](locked-changed-input.md) remains pending.

## Human validation records

**Locked Changed-Input Record: incomplete.** No student-authored AI-off prediction, prior GitHub commit/push or subsequent observation has been supplied. The linked record is an AI-prepared blank form. Complete it in the required order and include its full contents here before submission, preserving the student's original prediction verbatim. The Brightspace attachment must contain the completed record and immutable evidence links, not only a relative link to a blank template.

**Partner review: incomplete.** The [cold-run record](cold-run.md) tracks independent startup and operation; the [challenge record](partner-challenge.md) tracks the actual question, response, evidence and decision effect. Automated checks do not complete either personal activity.

On November 22, the student confirmed that the AI-off experiment and personal review have not been completed and no partner interaction occurred. The challenge file now includes an explicitly AI-generated practice critique for a possible discussion with Gage Hodson. It is preparation, not partner testimony or completed validation. The student subsequently requested no named client; the active app now uses an unnamed sample portfolio and labels its numerical mandate as proposed assumptions.

## Verification performed

Run `python3 run.py`, then the check command in the README. [Verification.txt](../outputs/Verification.txt) records the actual result. Tests compare estimates and the grid minimum against independent NumPy matrix calculations, reproduce the original Lab 15 allocation, check costs and named failures, verify retained hashes, reject unavailable/future/missing CPI inputs, audit saved investor memo bindings, exercise the real app controls, and run the README command in an isolated copy. [Cold-run evidence](cold-run.md) records the automated isolation result; no partner or remote clone is claimed.

Tests establish behavior for retained inputs and selected failure cases, not economic suitability, predictive skill, live data freshness or operational reliability. CPI is integrated for one exact vintage; broader historical validation needs a real vintage archive. The later-dated investor panel is kept outside portfolio calculations. A literal number audit cannot establish that a number was attached to the correct financial concept or that a qualitative inference is justified.

## Material AI uses

| Use | Tool/model/date | Disposition |
|---|---|---|
| Requirement review and integration of Labs 13–19 | OpenAI Codex; GPT-6 agent identity supplied by the session, exact runtime version not independently exposed; 2026-11-19 | Built a separate working project; preserved copied source data and formulas |
| Proposed CPI proxy, cost and risk controls | Same session | Explicitly marked provisional; compared with the Lab 15 reference; committee/student approval pending |
| Python model, vintage gate and Streamlit app | Same session | Checked against independent numerical calculations and UI/failure tests |
| Memo, data card, manifest and roadmap | Same session | Drafts linked to executed outputs; personal review pending |
| Earlier lab artifacts and saved persona memos | Prior AI-assisted lab work; earlier exact model versions not established here | Retained provenance and memo bindings; no new independent-persona vote or new source retrieval claimed |
| Project 1 feedback review and Project 2 document revision | OpenAI Codex; GPT-6 agent identity supplied by this session, exact runtime version not independently exposed; 2026-11-22 | Checked the current assignment/checklist; revised memo, provenance guidance, human record forms and delivery checks. Code, source data and saved financial outputs unchanged. No AI-off prediction or partner testimony authored |

No model or paid-data API is called when the project runs. No private credential or contact configuration is copied into this baseline. The student must personally review the work and truthfully add the required ownership statement to README, memo and videos; the assistant has not asserted that review happened.

## Open requirements

Required completion evidence: student review of the mandate and recommendation; independent AI-off prediction committed and pushed before the run, with before/after evidence and interpretation; personal AI-output check; independent cold run; final ownership statements; videos/transcripts; GitHub and Brightspace delivery. The [manifest](submission-manifest.md) tracks delivery.

Financial limitations affecting the recommendation and rubric quality: net rolling-five-year real outcomes, payouts/rebalancing, empirical liquidity and annual turnover, implementation-cost calibration and out-of-sample evaluation remain unestablished. These are not six additional submission files. They are material claims to test or limit honestly. See the [rubric review](rubric-review.md) for priorities; an honest pilot/reject is allowed, but disclaimers do not replace validation of the claims actually made.

## Submission freeze

After personal review and completion of the records, reconcile memo figures with the retained output and recordings. Publish the final evidence commit and use commit-specific GitHub links in the manifest. Attach the same final memo and validation Markdown files to Brightspace, together with the manifest and corrected transcripts or their links. Record the frozen commit, upload time and receipt in the manifest. The original `BASELINE.json` describes November 19's starting version; it is not a hash inventory of the revised submission.

## November 22 app review update

Removed the invented client identity from the active interface, configuration and documents at the student's request. Existing financial assumptions and methods are unchanged. Reproduced the saved scenarios and reran the project checks; these are AI-assisted development checks, not the student's locked experiment. The student reports the deadline as November 23 at 11:59 p.m. and has not created the GitHub repository. The personal experiment must wait until its prediction is committed and pushed.

## Rubric audit on November 22

OpenAI Codex (session identity GPT-6; exact runtime version not independently exposed) reviewed all six pages of the student-supplied rubric, inspected the calculation and test code, and checked raw price/CSV lineage and saved snapshot/output hashes. [Audit evidence](../outputs/rubric-review-checks.json) records the checks; [rubric review](rubric-review.md) maps the remaining gaps to all six categories. The 60-return sample supplies only one full five-year window. No fresh installation, partner activity, license verification or human prediction is claimed. The roadmap now prioritizes the mandate-to-evidence gap and authentic validation before final packaging.
