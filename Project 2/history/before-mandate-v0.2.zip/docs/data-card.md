# Data card and decision-time rules

Documents reviewed November 22, 2026. The model remains the frozen October 30 example; this review did not refresh market data.

## Facts and assumptions

| Input | Value and units | Dated basis | Status |
|---|---|---|---|
| Price history | 61 monthly adjusted USD price levels; 60 returns | Downloaded October 20, 2026; observations through September | Saved source evidence below |
| Inflation proxy | 3.717251% year over year | October 29, 2026 CPI vintage; September observations | Calculation supported; use as an expectation is proposed |
| Real return target | 3 percentage points above CPI, net, over rolling five years | Retained Lab 13 mandate | Fictional mandate proposal; not validated by annual screening |
| Additional annual costs | 0.25% of portfolio value per year | Adopted in the November 19 development baseline | Judgment; no execution-cost study supplied |
| Volatility ceiling / VT cap | 10% annualized / 60% of portfolio | Adopted in the November 19 development baseline | Proposed policy limits; not measured market facts |
| Initial reserve floor | 2% of portfolio | Four $50,000 payouts divided by $10 million | Derived from the mandate; fund eligibility remains provisional |

For a revised assumption, record its author, date, units, rationale and supporting source or policy approval. A development date identifies when a judgment entered the model; it does not supply independent support. Retain the existing source snapshots when comparing revisions.

## Prices

BIL, IEF, LQD and VT use saved monthly USD adjusted closes from Yahoo Finance, downloaded October 20, 2026. The 61 levels span September 2021–September 2026 and generate 60 monthly returns. Exact source URLs, timestamps, values and hashes are in [Prices.json](../sources/Prices.json); [raw responses](../sources/yahoo/) and [prices.csv](../prices.csv) are retained. The price/estimator lineage is unchanged from Lab 15.

First-of-month timestamps label monthly bars; they are not publication dates. Returns are price relatives minus one. Expected return is monthly arithmetic mean × 12; covariance is sample monthly covariance × 12. The 36-month switch uses 37 levels to produce 36 returns. Missing months, invalid prices and duplicate tickers are rejected rather than filled.

The portfolio gate requires the saved price download to predate the decision day and verifies raw hashes and CSV agreement. This allows the frozen October 30 example; it refuses an October 1 allocation using an October 20 download. It does not turn this later adjusted history into an archive of values available at every earlier rebalance. A full historical strategy backtest needs additional point-in-time data handling.

## CPI signal

Source: BLS CPIAUCSL through [FRED](https://fred.stlouisfed.org/series/CPIAUCSL) / [ALFRED](https://alfred.stlouisfed.org/series?seid=CPIAUCSL). Monthly, seasonally adjusted; index, 1982–1984 = 100. The [manifest](../sources/cpi-manifest.json) retains URLs, actual retrieval times and hashes; [snapshots](../sources/cpi/) came from Lab 17.

For decision date D, select **exactly D−1's retained ALFRED vintage**. Verify its hash, select its latest nonmissing observation, and obtain the same month one year earlier from that same snapshot. Calculate `latest / year_ago - 1`. Missing vintage, empty data, missing comparison month, invalid values or future observation labels stop the process. Never fall back to the retained current-data file; that file is evidence for the Lab 17 comparison only. `signal_data.py` implements the gate.

Default: decision October 30, 2026 → vintage October 29 → September CPI 336.298 / year-ago September 324.245 − 1 = 3.717251%. In CPI-proxy mode, this trailing inflation rate plus the 3% real target sets the annual net-return screen. Fixed-assumption mode uses the configured inflation rate instead while showing the signal separately. The default proxy is a proposed expectation method, not a statistical forecast or committee-approved CPI benchmark.

The earlier September 30 snapshot ends at August, demonstrating the publication delay. Earlier vintages also differ from later revised history. These retained audit examples motivated the rule. No same-day release eligibility is assumed; intraday publication times are not available in this baseline.

This implements one dated signal for a frozen allocation example. It does not establish predictive usefulness, a complete vintage archive for a strategy backtest, or a rolling real-return performance record. Signal admission for this example replaces the earlier blanket quarantine only for this explicit, tested path; arbitrary current-history shortcuts remain excluded.

## Investor research

NVDA annual SEC facts and provenance come from Lab 19 and the Lab 18 Buffett logic. The retained [SEC manifest](../sources/NVDA-manifest.json) records source dates and hashes. The [VT fact-sheet source record](../sources/VT-fact-sheet.source.json) explains why NVDA was selected. Annual financial values use eligible 10-K facts and record tags, periods and filings; no stock-price or valuation input is added.

This research was retrieved November 19, after the October 30 portfolio decision date. It is displayed as a separate review exhibit and cannot influence the allocation or inflation signal. Memo checks bind text to the same financial packet and policy thresholds, then audit literal numbers. They do not prove the interpretation or qualitative judgment.
