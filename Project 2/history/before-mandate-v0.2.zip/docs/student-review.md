# Project 2 in plain language

Build a small investment app and explain whether its portfolio-selection process deserves to be used. A well-supported decision to pilot or reject it is acceptable. You do not need a named client or a corporate valuation model.

Due: November 23, 2026 at 11:59 p.m., as reported by the student. Use the timezone shown in Brightspace.

## What the assignment requires

1. **A working app:** someone else can start it using your README.
2. **Rules for the portfolio:** its goal, investments allowed, comparison benchmark and risk limits. These rules are the mandate. Our existing numerical values are sample assumptions, not instructor-specified client facts.
3. **Three approaches compared:** equal weight; another simple method (ours gives larger weights to historically less volatile funds); and your portfolio chosen subject to the rules. Show which pass or fail and why.
4. **One dated signal:** use information available before the decision, with a data card explaining its source, timing and calculation. Ours is a saved inflation reading.
5. **Stress tests:** show what happens when estimates, the historical window, costs and limits change. Identify when the app should stop or reject the scenario.
6. **Your own prediction before one new test:** write it with AI off, put it on GitHub before the run, then compare it with what actually happened.
7. **A recommendation:** use, allocate, rebalance, pilot or reject the process, with an allocation range, monitoring rules and reasons you would change your decision.
8. **Honest disclosure:** identify the AI assistance, take responsibility for the analysis and decision after reviewing them, and state that this is educational work.

## Explore the app now

Open http://localhost:8522. This walkthrough is practice, not your required AI-off experiment.

1. Leave the sidebar unchanged initially. Keep the decision date at October 30, 2026; the saved data supports that example, not arbitrary dates.
2. In **Portfolio & mandate**, read the recommendation. The baseline allocates 55% to BIL and 45% to VT. BIL holds short-term Treasury bills; VT is a global stock fund. IEF and LQD are Treasury and corporate-bond funds, respectively.
3. Read the four metrics: estimated annual return after the additional cost, historical annualized volatility, reserve weight and minimum return screen. Volatility describes variation, not the worst possible loss.
4. Scroll to **Same assumptions, four portfolios**. Compare the weights and named reasons for PASS/FAIL. A modeled PASS covers only the implemented rules; the separate deployment FAIL records evidence still missing.
5. Click **Save current scenario JSON**. Save it with a recognizable name such as `practice-before.json`. It includes the control settings and results.
6. Open **Point-in-time signal**. Check the decision date, CPI vintage date and observation month. These dates mean different things: when the decision occurs, which historical data snapshot is allowed, and which month inflation describes.
7. Open **Stress tests**. These are existing, already-run examples. Compare their weights and results with Base; the tight-cap case shows the stop behavior. These known cases cannot count as an unseen personal prediction.
8. For practice, return to **Portfolio & mandate** and tick **Use last 36 return months** in the sidebar. Compare the new weights and metrics, then untick it to restore the default window. Save a separate practice result if useful. This case is already disclosed in the stress table.
9. Leave the remaining inputs at their defaults when you finish. Tell the assistant which labels, calculations or verdicts you could not explain.

**Changing a sidebar control reruns the app immediately.** Do not enter a new experiment value until your prediction for that case is written and committed to GitHub. The stress table also recalculates when controls change. Saved downloads do not change the default configuration file.

## Your recorded AI-off experiment, later

After you understand the controls, close AI assistance and choose a fresh input/value combination yourself. Before touching that control, write the old/new values and units, your expected changes to the results and recommendation, and why. Preserve the before output. Commit and push the prediction and baseline evidence to GitHub before entering the new value in the app.

Then change only the chosen input, save the after scenario under a different name, and explain the actual change or lack of change. Preserve your original prediction even if wrong. Use the [locked record](locked-changed-input.md) for the fields.

The student plans to create GitHub after completing development. That can work only if the required experiment is held until the repository exists: development complete → repository and prediction published → experiment → final submission update. A finished local file uploaded after the experiment does not establish the required before-run GitHub record.

## What the partner interaction is for

The Project 2 assignment requires an app a stranger can run. It does not name Gage Hodson or separately list a partner-criticism essay among its eight requirements. The related Lab 20 instructions specify a practical partner check:

- Give the partner the repository link and let them follow the README without coaching.
- Have them record the command, first failure (or none), time taken and where they found the result.
- Explain the code producing a decision number without AI; the partner asks a question and you answer from the code.
- Fix the first failure, if any, then have them try again. Record a clean run when no fix is needed.

The Project 1 feedback also asks for genuine partner challenge evidence. A short accurate note of the question, your answer and any resulting change is enough to document the interaction; do not invent a conversation. The [practice critique](partner-challenge.md) contains discussion prompts, not partner testimony.

## What you submit

Publish the repository, decision memo, validation/AI-use record including your completed locked experiment, and a manifest locating the evidence. Attach the required Markdown documents to Brightspace. Supply three YouTube links with corrected transcripts:

- **Video 1, up to 3 minutes:** how the work and your thinking changed; one AI output you personally checked.
- **Video 2, up to 5 minutes:** explain the relevant code and validation.
- **Video 3, up to 5 minutes:** begin with the running app and present the committee decision.

Keep your face visible in every recording, as required by the instructor's feedback. Use the [video checklist](video-checklist.md) and [submission manifest](submission-manifest.md). Edition A/B and the separate Research-Evolution upload are excluded for Project 2 by the course checklist.

Before recording, be able to explain the portfolio rules, why the methods differ, how the dated signal is used, and why the current recommendation is paper testing with no new capital. Tell the assistant where you disagree or need explanation. Personal ownership means reviewing and accepting the reasoning, not simply adding a sentence to the memo.
