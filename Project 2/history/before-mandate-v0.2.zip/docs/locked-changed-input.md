# Locked Changed-Input Record — pending

No human AI-off prediction or prior GitHub commit/push has been provided. The baseline and its displayed stresses have known outcomes and cannot be presented as an unseen prediction. The baseline ZIP is a version reference, not evidence of this personal activity.

This is an AI-prepared blank form. Only the student can supply the AI-off prediction. Do not ask AI to choose the experiment, suggest its expected direction or rewrite the prediction. Existing baseline and stress outputs remain development evidence.

## Required order

1. Close AI assistance. Choose a fresh load-bearing input whose changed-case outcome you have not already inspected. Save the baseline settings and before output under distinct filenames.
2. Write the prediction below yourself, including what may happen to the portfolio numbers, rule verdict and committee recommendation. Use a timestamp with timezone.
3. Commit and push the prediction, baseline settings and before output to GitHub. Record the commit-specific link and confirm it is accessible **before** executing the changed case. This local folder currently has no Git repository; publication remains pending.
4. Run the changed case. Save its settings and after output under different filenames; the normal report command overwrites its standard output files.
5. Add the observation in a later commit. Preserve the original prediction verbatim, including any wrong expectation. Diagnose disagreement or no change using the actual result.

If a prediction was not recorded before a past run, label that activity incomplete. Do not backdate it. Ask the instructor about a remedy if a fresh experiment will not satisfy the requirement.

## Prediction, before execution

- Student, date/time: PENDING.
- Student confirmation that AI was off while choosing the change and writing the prediction: PENDING.
- Load-bearing input, old/new values, units and why it matters: PENDING.
- Other inputs held fixed: PENDING.
- Expected direction, reason and decision effect: PENDING.
- Before-output file and immutable GitHub link: PENDING.
- Baseline configuration and model/source commit: PENDING.
- Prediction commit hash, URL and push time: PENDING.

## Observation, after execution

- Exact command/control and execution time: PENDING.
- After-output file and immutable GitHub link: PENDING.
- Changed configuration file and confirmation only the recorded input changed: PENDING.
- Actual before/after numbers and units: PENDING.
- Agreement/disagreement/no change; diagnosis: PENDING.
- Recommendation after the result: PENDING.
- Result commit and URL: PENDING.

## Final evidence check

- Prediction commit/push precedes execution; timestamps include timezones.
- Old/new values use the same units; baseline and changed-case outputs are both retained.
- The observation covers numerical direction, pass/fail rules and the recommendation, including an unchanged decision.
- The final validation document includes this completed record, with commit-specific evidence links, so its Brightspace attachment is self-contained.
