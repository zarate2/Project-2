AI disclosure: OpenAI Codex assisted with implementation, testing and drafting. Student ownership confirmation is pending.

For education, not investment advice.

# Portfolio process decision

**PILOT in paper research only, with 0% new capital authorized. Reverse toward adoption only after the committee approves the mandate and signal, net rolling-five-year/payout validation passes, and liquidity, turnover and implementation costs are evidenced.**

Model version 0.1.0; financial results reproduced November 22, 2026. Portfolio decision date October 30, 2026, using saved monthly prices through September downloaded October 20 and CPI vintage October 29. The sample mandate assumes $10 million, seven years and $50,000 quarterly distributions. Its objective is CPI + 3% net over rolling five years; the initial reserve floor is 2%. These are proposed exercise assumptions, not requirements for a named client.

The baseline selects **55% BIL / 45% VT**, with IEF and LQD at zero. Estimated gross return is **7.33%**, net proxy **7.08%**, annual volatility **6.78%**, and provisional reserve weight **55%**. This is a minimum-volatility result among five-point grid allocations under the stated estimates, not an implementation recommendation.

The assumptions needing approval are trailing CPI inflation as an expectation proxy, 0.25% additional annual costs, a 10% modeled volatility ceiling and 60% VT cap. Same-vintage September CPI values of 336.298 and 324.245 imply **3.717251%** trailing inflation. Adding the 3% real target gives a **6.717251%** net annual return screen. This screen does not establish rolling-five-year performance. The assumptions explain the change from Lab 15's fixed-inflation, zero-added-cost allocation of 75% BIL / 25% VT.

Equal weight has a **2.97%** net estimate and fails the return screen; inverse volatility has **3.08%** and fails it too. The 60% VT / 40% LQD reference has **6.56%** net, **12.29%** volatility and zero reserve, failing the return, volatility and reserve screens. Every portfolio fails the deployment gate pending approval and evidence.

| Changed dimension | Research allocation BIL / VT | Net proxy | Volatility | Implication |
|---|---:|---:|---:|---|
| VT return estimate −1 percentage point | 50% / 50% | 6.99% | 7.52% | More equity needed to satisfy the target |
| Window shortened to 36 returns | 80% / 20% | 7.29% | 2.37% | Allocation depends strongly on estimates |
| Additional annual cost 0.25% → 1.25% | 45% / 55% | 6.91% | 8.26% | More equity and risk to clear the net screen |
| VT cap 60% → 25% | No feasible mix | — | — | Reject this scenario; stop rather than relax limits |

The observed research range is **45–80% BIL and 20–55% VT**, with IEF/LQD zero across feasible cases. This is a range across scenarios, not permission to choose any combination within those bounds. It excludes the infeasible case and authorizes no capital. Lower expected VT returns and higher costs cause the optimizer to add equity to meet the return screen. That response deserves committee scrutiny before approving the objective and risk limits.

Labs 18–19 provide supplementary November 19 research on NVDA, a holding selected from the retained VT fact sheet. The saved educational judgments disagree: Buffett “Watch it,” Wood “Own the business,” Burry “Pass.” These are persona exercises, not the investors' actual opinions or a valuation. Their later information is excluded from the October 30 allocation and never used to turn a company view into an ETF weight.

Monitor reserve coverage and liquidity before payouts; turnover before trades; source/vintage eligibility at each rebalance; realized risk against an approved breach policy; and net real rolling returns when enough history exists. Stop on infeasibility, missing vintage, failed source integrity or invalid inputs. A demand to deploy capital before approval and validation changes the decision to reject. The next phase must validate payouts, net rolling outcomes, transaction costs, liquidity and turnover, then reconsider the recommendation.

**Committee ask:** authorize paper testing only. Require evidence of payout funding, net rolling-five-year results, executable liquidity, turnover and costs before reconsidering capital deployment.

Figures: [executed output](../outputs/visible-output.md), [full-precision results](../outputs/results.json). Assumptions and provenance: [mandate](mandate.md), [data card](data-card.md). Tests and remaining evidence: [validation record](validation-and-ai-use.md).
