"""Project 2 working application. Run: python3 -m streamlit run app.py"""
from datetime import date
import json
import streamlit as st
import model
import panel
from research import investor_review
from run import stress_rows

st.set_page_config(page_title='Project 2 | Investment Management', page_icon='📊', layout='wide')
st.caption(model.ANNOUNCEMENT)
st.title('Project 2 · Investment Management')
config = model.load_config()
st.caption(f"Version {config['version']} · frozen lab evidence · sample portfolio mandate; no named client")
st.caption('Sample assumptions: USD 10 million portfolio, seven years, USD 50,000 quarterly payouts, and CPI + 3% net over rolling five years. These are proposed exercise settings.')
with st.sidebar:
    st.header('Portfolio assumptions')
    config['decision_date'] = st.date_input('Portfolio decision date', date.fromisoformat(config['decision_date'])).isoformat()
    st.caption('Retained default: October 30, 2026. Missing prior-day vintage stops the process.')
    modes = ['vintage_cpi_proxy', 'fixed_assumption']
    config['inflation_mode'] = st.selectbox('Inflation input', modes, index=modes.index(config['inflation_mode']),
                                           format_func=lambda x: 'Prior-day CPI vintage · trailing inflation proxy' if x == modes[0] else 'Fixed inflation assumption')
    config['fixed_inflation'] = st.number_input('Fixed inflation assumption (%)', min_value=0.0, max_value=20.0,
                                               value=config['fixed_inflation']*100, step=.25, disabled=config['inflation_mode'] != 'fixed_assumption')/100
    config['last_36'] = st.checkbox('Use last 36 return months', value=config['last_36'])
    config['vt_return_shift'] = st.number_input('VT expected return shift (percentage points)', min_value=-50.0, max_value=50.0,
                                               value=config['vt_return_shift']*100, step=.5)/100
    config['additional_annual_cost'] = st.number_input('Additional annual cost (%)', min_value=0.0, max_value=5.0,
                                                       value=config['additional_annual_cost']*100, step=.25)/100
    config['reserve_floor'] = st.number_input('Reserve floor (%)', min_value=0.0, max_value=100.0,
                                             value=config['reserve_floor']*100, step=1.0)/100
    config['volatility_limit'] = st.number_input('Proposed annual volatility limit (%)', min_value=0.0, max_value=100.0,
                                                value=config['volatility_limit']*100, step=1.0)/100
    config['equity_weight_limit'] = st.number_input('Proposed VT weight cap (%)', min_value=0.0, max_value=100.0,
                                                   value=config['equity_weight_limit']*100, step=5.0)/100
    st.caption('Changing a control immediately reruns the app. For the locked experiment, publish your AI-off prediction before changing the input. Edits affect this session. Save the scenario to preserve it; update config.json to change the project default.')

try:
    result = model.calculate(config)
except (ValueError, OSError, KeyError) as exc:
    st.error(f'STOP: {exc}')
    st.stop()

st.info(result['decision'])
tabs = st.tabs(['Portfolio & mandate', 'Point-in-time signal', 'Stress tests', 'Investor research', 'Baseline & next changes'])
with tabs[0]:
    mix = result['portfolios']['Constrained portfolio']
    if mix is None:
        st.error(result['status'])
    else:
        cols = st.columns(4)
        cols[0].metric('Net annual return proxy', f"{mix['net_return']:.2%}")
        cols[1].metric('Annual volatility', f"{mix['volatility']:.2%}")
        cols[2].metric('Reserve weight', f"{mix['reserve']:.0%}")
        cols[3].metric('Net return screen', f"{result['net_return_target']:.2%}")
        st.bar_chart({'Asset': config['tickers'], 'Weight': [w*100 for w in mix['weights']]},
                     x='Asset', y='Weight', y_label='Allocation (%)')
    st.subheader('Same assumptions, four portfolios')
    st.dataframe(model.table_rows(result), hide_index=True, width='stretch')
    if mix is not None:
        st.dataframe([{'Rule': k, 'Result': v} for k,v in mix['rules'].items()], hide_index=True, width='stretch')
    st.warning('Deployment verdict: FAIL — committee approval, net rolling-five-year outcomes, payout paths, observed liquidity and annual turnover remain unvalidated.')
    st.caption('Returns use annualized arithmetic means. Additional cost is a flat annual deduction beyond expenses embedded in adjusted prices. '
               'BIL/IEF reserve eligibility is provisional; IEF still has price risk. The volatility limit is not a maximum-loss guarantee.')
    st.download_button('Save current scenario JSON', json.dumps(result, indent=2), 'project2-scenario.json', 'application/json')

with tabs[1]:
    signal = result['signal']
    st.subheader('CPI: information available before the decision')
    st.metric('Trailing 12-month inflation', f"{signal['year_over_year']:.4%}")
    st.write(f"Decision {signal['decision_date']} → prior-day vintage {signal['vintage_date']} → latest observation {signal['observation_date'][:7]}.")
    st.code(f"{signal['level']:.3f} / {signal['prior_level']:.3f} - 1 = {signal['year_over_year']:.8f}")
    st.write(f"Both index levels come from the same vintage. In CPI-proxy mode this result plus the {config['real_return_target']:.2%} real target sets the return screen. "
             'In fixed-assumption mode the CPI remains visible but does not set the return target.')
    st.markdown(f"[Retained source URL]({signal['url']})")
    st.caption(f"Downloaded {signal['downloaded_utc']}; SHA-256 {signal['sha256']}")
    st.warning('Trailing inflation is a proposed proxy for expected inflation. It is not a prediction, and passing its annual screen does not prove the rolling-five-year mandate.')

with tabs[2]:
    scenarios = model.stress_suite(config)
    st.subheader('Estimate, window, costs and constraints')
    st.dataframe(stress_rows({'scenarios': scenarios}), hide_index=True, width='stretch')
    st.write('Each row changes one dimension from the current controls. The window change recomputes means, volatility and correlations together. '
             'The constraint case tightens the VT cap to at most 25%; if already at or below 25%, that row is unchanged.')
    st.error('Stop on infeasibility, missing vintage, source mismatch or invalid inputs. Never silently relax the mandate.')
    st.download_button('Save stress results JSON', json.dumps(scenarios, indent=2), 'project2-stresses.json', 'application/json')

with tabs[3]:
    st.subheader('NVDA · three investor lenses from Labs 18–19')
    st.caption('Retained November 19 research on a VT holding. It is outside the October 30 portfolio information set and does not drive weights.')
    try:
        review = investor_review()
        packet = review['packet']
        st.dataframe(panel.panel_rows(packet), hide_index=True, width='stretch')
        for name, memo in review['memos'].items():
            with st.expander(name + ' · ' + memo['verdict']):
                st.markdown(memo['text'])
                if memo['bound_to_packet'] and not memo['unsupported_numbers']:
                    st.success('Saved memo matches the fact packet and thresholds; literal numeric audit passes.')
                else:
                    st.error('Memo needs review: changed facts/thresholds or unsupported numbers.')
        st.caption('Educational persona analysis, not these investors\' actual opinions or three independent models. '
                   'Numeric support does not verify metric/year meaning or qualitative claims. No stock prices or valuation are included.')
        st.download_button('Save investor evidence', panel.render_report(packet), 'NVDA-panel.md', 'text/markdown')
    except (OSError, ValueError, KeyError) as exc:
        st.error(f'Investor research unavailable: {exc}')

with tabs[4]:
    st.subheader('A starting version we can revise')
    st.write('Default decisions and assumptions live in config.json. The original lab estimator is preserved in portfolio.py; '
             'model.py adds costs, policy checks and the vintage signal. The baseline ZIP preserves version 0.1.0.')
    st.write('Next decisions: review the mandate and benchmark; choose the inflation expectation method; approve risk/cost assumptions; '
             'validate payout paths, rolling real returns and turnover; then review the research-only recommendation.')
    st.write('Human/submission steps remain separate: AI-off prediction committed before its run, partner cold run, personal ownership statement, '
             'videos/transcripts, GitHub URLs and Brightspace submission.')
