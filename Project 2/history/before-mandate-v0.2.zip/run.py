"""Offline one-command project result. Run: python3 run.py"""
import json
from pathlib import Path
import model
from research import investor_review

ROOT = Path(__file__).resolve().parent


def build_report():
    config = model.load_config()
    scenarios = model.stress_suite(config)
    review = investor_review()
    legacy = model.calculate(dict(config, inflation_mode='fixed_assumption', fixed_inflation=.025,
                                  additional_annual_cost=0.0, vt_return_shift=0.0, last_36=False,
                                  volatility_limit=.10, equity_weight_limit=.60, reserve_floor=.02))
    return {'version': config['version'], 'review_date': '2026-11-22', 'scenarios': scenarios,
            'lab15_reference': legacy,
            'investor_review': {'scope': review['scope'], 'verdicts': {k: v['verdict'] for k,v in review['memos'].items()},
                                'numeric_audits_clean': all(v['bound_to_packet'] and not v['unsupported_numbers'] for v in review['memos'].values()),
                                'sources': review['packet']['sources']}}


def stress_rows(report):
    rows = []
    for name, result in report['scenarios'].items():
        row = result['portfolios']['Constrained portfolio']
        rows.append({'Scenario': name, 'BIL / IEF / LQD / VT': 'No feasible mix' if row is None else ' / '.join(f'{w:.0%}' for w in row['weights']),
                     'Net proxy': '—' if row is None else f"{row['net_return']:.2%}",
                     'Volatility': '—' if row is None else f"{row['volatility']:.2%}", 'Status': result['status']})
    return rows


def render(report):
    base = report['scenarios']['Base']
    c, signal = base['config'], base['signal']
    feasible = [r['portfolios']['Constrained portfolio']['weights'] for r in report['scenarios'].values()
                if r['portfolios']['Constrained portfolio'] is not None]
    research_range = '; '.join(f"{ticker}: {min(w[i] for w in feasible):.0%}–{max(w[i] for w in feasible):.0%}"
                               for i, ticker in enumerate(c['tickers'])) if feasible else 'No feasible tested allocation'
    legacy = report['lab15_reference']['portfolios']['Constrained portfolio']
    sections = [model.ANNOUNCEMENT, '# Project 2 — baseline ' + report['version'], base['decision'],
        f"Review date: {report['review_date']}. Portfolio decision date: {c['decision_date']}. "
        f"Prices downloaded {base['price_source']['download_date']}, through {base['price_source']['last_price_month']}. "
        'No market data is refreshed by this command.',
        '## Material inputs',
        f"{c['portfolio_label']}: ${c['portfolio_value_usd']:,.0f}; quarterly payouts ${c['quarterly_payout_usd']:,.0f}; "
        f"horizon {c['horizon_years']} years. Effective reserve floor {base['effective_reserve_floor']:.2%}. "
        f"Additional annual cost {c['additional_annual_cost']:.2%}; proposed volatility limit {c['volatility_limit']:.2%}; "
        f"proposed VT cap {c['equity_weight_limit']:.0%}. These proposed controls require committee review.",
        f"CPI vintage {signal['vintage_date']}: latest measured month {signal['observation_date'][:7]}, "
        f"index {signal['level']:.3f} versus {signal['prior_level']:.3f} one year earlier. "
        f"Trailing inflation = {signal['year_over_year']:.6%}. Inflation mode: `{c['inflation_mode']}`; "
        f"inflation used {base['inflation_used']:.6%} plus real target {c['real_return_target']:.2%} "
        f"gives net return screen {base['net_return_target']:.6%}. "
        'Trailing inflation is a proposed expectation proxy; this arithmetic annual screen does not establish net rolling-five-year performance.',
        '## Baselines and constrained portfolio', model.markdown_table(model.table_rows(base)),
        '## Four stress dimensions', model.markdown_table(stress_rows(report)),
        f'Research allocation range over feasible cases: **{research_range}**. Live allocation authorization: **0% new capital**. '
        'An infeasible case has no portfolio and is excluded from that range; it is never replaced with relaxed constraints.',
        '## Connection to the earlier labs',
        ('With the fixed 2.5% inflation assumption and zero additional costs, the retained Lab 15 reference is '
         f"{' / '.join(f'{w:.0%}' for w in legacy['weights'])} in BIL / IEF / LQD / VT, "
         f"{legacy['gross_return']:.2%} gross return and {legacy['volatility']:.2%} volatility.") if legacy else 'Lab 15 reference infeasible under the current non-reference mandate fields.',
        'This baseline uses the dated CPI proxy and additional-cost screen explicitly, so its starting weights can differ from Lab 15. '
        'Investor research is supplementary: ' + '; '.join(f'{k}: {v}' for k,v in report['investor_review']['verdicts'].items()) + '. '
        'These educational persona judgments are not the actual investors\' opinions and do not change ETF weights.',
        '## Decision conditions and remaining work',
        'The modeled checks cover fully funded long-only weights, a net return proxy, reserve coverage, modeled annual volatility and the VT cap. '
        'Every deployment verdict fails pending approval and evidence. The mandate also requires 90% five-day liquidity, an 8% nonexempt issuer cap, '
        'and 25% annual turnover without approval. Fund exemptions are an exercise convention; execution and eligibility need verification.',
        'Stop when the grid is infeasible, required vintage is missing, source hashes do not match, or inputs are invalid. '
        'Monitor reserves/liquidity before payouts, turnover before trades, vintage eligibility at each rebalance, realized risk against approved limits, '
        'and net real rolling returns when sufficient history exists. A mandate to deploy before the approval/validation gates pass changes the decision to reject.',
        'AI-off prediction and prior GitHub commit, partner cold run, student ownership statement, video recordings/transcripts and final publication remain pending. '
        'This baseline is a starting version for iteration, not a completed submission.',
        'Full precision and all inputs are in `outputs/results.json`. Run `python3 run.py` from this project folder to reproduce.']
    return '\n\n'.join(sections) + '\n'


def main():
    report = build_report()
    text = render(report)
    output = ROOT / 'outputs'
    output.mkdir(exist_ok=True)
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    (output / 'visible-output.md').write_text(text)
    print(text)
    print('Saved outputs/results.json and outputs/visible-output.md')


if __name__ == '__main__':
    main()
