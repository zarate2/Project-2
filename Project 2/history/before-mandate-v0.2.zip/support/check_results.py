"""Independent numerical, information-timing, UI and portability checks."""
from copy import deepcopy
from datetime import date, datetime, timezone
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from urllib.parse import unquote

import numpy as np
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import model
import run
import signal_data
from research import investor_review


class ProjectChecks(unittest.TestCase):
    def test_imported_sources_unchanged(self):
        for item in json.loads((ROOT / 'sources/import-manifest.json').read_text()):
            self.assertEqual(sha256((ROOT / item['file']).read_bytes()).hexdigest(), item['sha256'], item['file'])
        for item in json.loads((ROOT / 'sources/NVDA-manifest.json').read_text()):
            self.assertEqual(sha256((ROOT / 'sources' / item['file']).read_bytes()).hexdigest(), item['sha256'])
        fact_sheet = json.loads((ROOT / 'sources/VT-fact-sheet.source.json').read_text())
        self.assertEqual(sha256((ROOT / 'sources/VT-fact-sheet.pdf').read_bytes()).hexdigest(), fact_sheet['sha256'])

    def test_point_in_time_signal_and_no_current_fallback(self):
        signal = signal_data.cpi_signal('2026-10-30')
        self.assertEqual(signal['vintage_date'], '2026-10-29')
        self.assertEqual(signal['observation_date'], '2026-09-01')
        self.assertAlmostEqual(signal['year_over_year'], 336.298 / 324.245 - 1)
        earlier = signal_data.cpi_signal('2026-10-01')
        self.assertEqual(earlier['observation_date'], '2026-08-01')
        with self.assertRaisesRegex(ValueError, 'No retained CPI vintage'):
            signal_data.cpi_signal('2026-11-19')
        with self.assertRaisesRegex(ValueError, 'not available before'):
            signal_data.verify_prices('2026-10-01')

    def test_corrupt_future_and_missing_comparison_cpi_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            shutil.copytree(ROOT / 'sources/cpi', root / 'sources/cpi')
            meta = json.loads((ROOT / 'sources/cpi-manifest.json').read_text())
            record = next(r for r in meta if r['file'].endswith('vintage-2026-10-29.csv'))
            path = root / record['file']
            original = path.read_text()
            (root / 'sources/cpi-manifest.json').write_text(json.dumps(meta))
            path.write_text(original + '\n')
            with self.assertRaisesRegex(ValueError, 'hash mismatch'):
                signal_data.cpi_signal('2026-10-30', root)
            for text, error in [(original + '2027-01-01,340\n', 'after the requested vintage'),
                                ('\n'.join(line for line in original.splitlines() if not line.startswith('2025-09-01')) + '\n', 'Missing year-ago')]:
                path.write_text(text)
                record['sha256'] = sha256(path.read_bytes()).hexdigest()
                (root / 'sources/cpi-manifest.json').write_text(json.dumps(meta))
                with self.assertRaisesRegex(ValueError, error):
                    signal_data.cpi_signal('2026-10-30', root)

    def test_independent_moments_and_exhaustive_grid(self):
        prices = np.genfromtxt(ROOT / 'prices.csv', delimiter=',', skip_header=1)[:, 1:]
        monthly = prices[1:] / prices[:-1] - 1
        grid = np.array([[a,b,c,20-a-b-c] for a in range(21) for b in range(21-a) for c in range(21-a-b)]) / 20
        self.assertEqual(len(grid), 1771)
        for scenario in model.stress_suite().values():
            cfg = scenario['config']
            data = monthly[-36:] if cfg['last_36'] else monthly
            mean = data.mean(axis=0) * 12
            mean[3] += cfg['vt_return_shift']
            covariance = np.cov(data.T) * 12
            np.testing.assert_allclose([s['return'] for s in scenario['estimate']['sleeves']], mean)
            net = grid @ mean - cfg['additional_annual_cost']
            vols = np.sqrt(np.einsum('ij,jk,ik->i', grid, covariance, grid))
            eligible = ((net >= scenario['net_return_target'] - 1e-12)
                        & (grid[:, :2].sum(axis=1) >= scenario['effective_reserve_floor'] - 1e-12)
                        & (vols <= cfg['volatility_limit'] + 1e-12)
                        & (grid[:, 3] <= cfg['equity_weight_limit'] + 1e-12))
            actual = scenario['portfolios']['Constrained portfolio']
            if not eligible.any():
                self.assertIsNone(actual)
            else:
                expected = grid[eligible][vols[eligible].argmin()]
                np.testing.assert_allclose(actual['weights'], expected)
                self.assertAlmostEqual(actual['volatility'], float(vols[eligible].min()))
            for row in scenario['portfolios'].values():
                if row is not None:
                    weights = np.array(row['weights'])
                    self.assertAlmostEqual(row['net_return'], float(weights @ mean - cfg['additional_annual_cost']))
                    self.assertAlmostEqual(row['volatility'], float(np.sqrt(weights @ covariance @ weights)))

    def test_baseline_legacy_and_named_failures(self):
        report = run.build_report()
        base = report['scenarios']['Base']
        self.assertEqual(base['portfolios']['Constrained portfolio']['weights'], [.55,0,0,.45])
        saved = json.loads((ROOT / 'sources/lab-reference/Lab15-results.json').read_text())['all_months']['mix']
        legacy = report['lab15_reference']['portfolios']['Constrained portfolio']
        self.assertEqual(legacy['weights'], saved['weights'])
        self.assertAlmostEqual(legacy['gross_return'], saved['return'])
        self.assertAlmostEqual(legacy['volatility'], saved['volatility'])
        for name in ('Equal weight', 'Inverse volatility'):
            self.assertEqual(len(base['portfolios'][name]['failed_rules']), 1)
            self.assertIn('Net return', base['portfolios'][name]['failed_rules'][0])
        self.assertEqual(len(base['portfolios']['60/40 benchmark']['failed_rules']), 3)
        self.assertTrue(all(row['deployment_verdict'].startswith('FAIL') for row in base['portfolios'].values()))
        costs = report['scenarios']['Cost: plus 1 percentage point annually']
        for name in ('Equal weight', 'Inverse volatility', '60/40 benchmark'):
            self.assertAlmostEqual(base['portfolios'][name]['net_return'] - costs['portfolios'][name]['net_return'], .01)
        self.assertIsNone(report['scenarios']['Constraint: VT cap tightened to at most 25%']['portfolios']['Constrained portfolio'])

    def test_invalid_config_and_payout_floor(self):
        for key, value in [('additional_annual_cost', -.01), ('vt_return_shift', float('nan')),
                           ('portfolio_value_usd', float('nan')), ('volatility_limit', 1.1)]:
            with self.assertRaises(ValueError):
                model.calculate(dict(model.load_config(), **{key: value}))
        case = model.calculate(dict(model.load_config(), reserve_floor=0.0))
        self.assertAlmostEqual(case['effective_reserve_floor'], .02)
        case = model.calculate(dict(model.load_config(), quarterly_payout_usd=250000))
        self.assertAlmostEqual(case['effective_reserve_floor'], .10)
        with self.assertRaisesRegex(ValueError, 'exceeds portfolio'):
            model.calculate(dict(model.load_config(), quarterly_payout_usd=3000000))

    def test_investor_evidence_binding(self):
        review = investor_review()
        self.assertEqual([v['verdict'] for v in review['memos'].values()], ['Watch it', 'Own the business', 'Pass'])
        for memo in review['memos'].values():
            self.assertTrue(memo['bound_to_packet'])
            self.assertFalse(memo['unsupported_numbers'])

    def test_app_control_changes_and_stop(self):
        app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30).run()
        self.assertFalse(app.exception)
        self.assertEqual([m.value for m in app.metric][:4], ['7.08%', '6.78%', '55%', '6.72%'])
        shift = next(i for i in app.number_input if i.label.startswith('VT expected'))
        shift.set_value(-1.0).run()
        self.assertFalse(app.exception)
        self.assertEqual([m.value for m in app.metric][:3], ['6.99%', '7.52%', '50%'])
        next(i for i in app.number_input if i.label.startswith('Proposed VT')).set_value(25.0).run()
        self.assertFalse(app.exception)
        self.assertIn('no feasible', app.error[0].value)
        app.date_input[0].set_value(date(2026,11,19)).run()
        self.assertFalse(app.exception)
        self.assertIn('No retained CPI vintage', app.error[0].value)
        self.assertFalse(app.metric)

    def test_app_legacy_controls(self):
        app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30).run()
        app.selectbox[0].set_value('fixed_assumption').run()
        next(i for i in app.number_input if i.label == 'Additional annual cost (%)').set_value(0.0).run()
        self.assertFalse(app.exception)
        self.assertEqual([m.value for m in app.metric][:4], ['5.67%', '3.83%', '75%', '5.50%'])

    def test_isolated_readme_run(self):
        with tempfile.TemporaryDirectory(prefix='project2-cold-') as temp:
            folder = Path(temp) / 'project'
            shutil.copytree(ROOT, folder, ignore=shutil.ignore_patterns('.venv','__pycache__','*.pyc','.git'))
            started = time.perf_counter()
            proc = subprocess.run(['python3','run.py'], cwd=folder, text=True, capture_output=True, timeout=30)
            elapsed = time.perf_counter() - started
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertIn('55.00% / 0.00% / 0.00% / 45.00%', proc.stdout)
            hashes = {}
            for name in ('results.json','visible-output.md'):
                raw = (folder / 'outputs' / name).read_bytes()
                self.assertEqual(raw, (ROOT / 'outputs' / name).read_bytes())
                hashes[name] = sha256(raw).hexdigest()
            record = {'performed_by':'Codex automated local isolation check; not a partner or remote clone',
                      'run_utc':datetime.now(timezone.utc).isoformat(), 'command':'python3 run.py',
                      'isolated_folder':str(folder), 'elapsed_seconds':round(elapsed,4),
                      'exit_code':proc.returncode, 'first_failure':None,
                      'result_location':'terminal and outputs/visible-output.md, outputs/results.json', 'output_hashes':hashes}
            (ROOT / 'outputs/cold-run.json').write_text(json.dumps(record,indent=2)+'\n')
            (ROOT / 'outputs/cold-run.txt').write_text(proc.stdout+proc.stderr)

    def test_local_links_and_output_consistency(self):
        report = run.build_report()
        self.assertEqual(json.loads((ROOT / 'outputs/results.json').read_text()), report)
        self.assertEqual((ROOT / 'outputs/visible-output.md').read_text(), run.render(report))
        for file in [ROOT/'README.md', ROOT/'CHANGELOG.md', *sorted((ROOT/'docs').glob('*.md'))]:
            for link in re.findall(r'\]\(([^)]+)\)', file.read_text()):
                if '://' not in link and not link.startswith('#'):
                    self.assertTrue((file.parent / unquote(link.split('#')[0])).exists(), f'{file.name}: {link}')
        memo = (ROOT/'docs/decision-memo.md').read_text()
        self.assertIn(model.DECISION, memo)
        for scenario in report['scenarios'].values():
            row = scenario['portfolios']['Constrained portfolio']
            if row:
                self.assertIn(f"{row['net_return']:.2%}", memo)
                self.assertIn(f"{row['volatility']:.2%}", memo)


if __name__ == '__main__':
    (ROOT/'outputs/Verification.txt').write_text('Verification in progress.\n')
    log = StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ProjectChecks))
    (ROOT/'outputs/Verification.txt').write_text(log.getvalue())
    print(log.getvalue())
    sys.exit(0 if result.wasSuccessful() else 1)
